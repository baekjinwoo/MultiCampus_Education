package chap9;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;

class Meeting{
	int id;
	int starttime;
	int endtime;
}
//종료시간 빠르면 더 많은 회의를 할 수 있다

public class MeetingRoomTest {
public static void main(String[] args) {
	int[][] rooms = { { 1, 1, 10 },
			{ 2, 5, 6 },
			{ 3, 13, 15 },
			{ 4, 14, 17 },
			{ 5, 8, 14 },
			{ 6, 3, 12 } };
/*
 class A implements  Comparator<Integer>{
  public int compareTo(Integer i, Integer j){
   return -, 0, 1
 }
  
  Arrays.sort(int[], 
  new Comparator<Integer>() {
  public int compareTo(Integer i, Integer j){
   return -, 0, 1
 } );
  
 * */	
//rooms 배열 정렬 종료시간 오름차순:
Arrays.sort(rooms, 
new Comparator<int[]>(){
	public int compare(int[] o1, int[] o2) {
	  return o1[2] - o2[2]; //음수  0 양수
	}
}
);

for(int i=0; i < rooms.length; i++){
	System.out.println
	(rooms[i][0]+":"+rooms[i][1]+":"+rooms[i][2]);
}
//ArrayList 결과 저장
ArrayList<int[]> list = new ArrayList<int[]>();
list.add(rooms[0]);//종료시간 가장 빠른 회의 저장

for(int i = 1; i < rooms.length; i++ ){
	if(list.get(list.size()-1)[2] <=  rooms[i][1]){
		list.add(rooms[i]);
	}
}
//============
for(int[] m : list){
	System.out.println(m[0] + " 번 회의 ");
}


// 2 5 4
}
}
