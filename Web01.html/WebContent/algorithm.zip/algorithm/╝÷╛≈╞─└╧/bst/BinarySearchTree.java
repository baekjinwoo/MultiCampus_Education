package bst;

public class BinarySearchTree {
	Node root;
	BinarySearchTree(){
		this.root = null;
	}
	public Node getRoot() {
		return root;
	}
	public void setRoot(Node root) {
		this.root = root;
	}
	//중위 우선 조회-오름차순
	public void display(Node n){
		if(n != null){
			display(n.getLeft());
			System.out.print(n.getKey() + " ");
			display(n.getRight());
		}
	}
	
	public boolean find(int id){
		Node current = root;
		int cnt = 0;
		while(current != null){
			cnt++;
			System.out.println(cnt);
			//System.out.println(id+":"+current);
			if(current.getKey() == id){
				return true;//id 있다
			}else if(current.getKey() > id){
				current = current.getLeft();
			}else {
				current = current.getRight();
			}
		}
		return false;//id 없다
	}
	//전체갯수 / 2 
	public void insert(int id){
		Node newNode = new Node(id);
		if(root == null){//트리구성노드 x
			root = newNode;
			return;
		}
		Node current = root;
		Node parent = null;
		while(true){
			parent = current;
			//현재노드보다 작으면
			if(current.getKey() > id){
				//왼쪽노드로 설정
				current = current.getLeft();
				if(current == null){//왼쪽자식 없다면
					parent.setLeft(newNode);
					return;
				}
			}
			else{
				current = current.getRight();
				if(current == null){
					parent.setRight(newNode);
					return;
				}
			}
			
		}
	}
}








