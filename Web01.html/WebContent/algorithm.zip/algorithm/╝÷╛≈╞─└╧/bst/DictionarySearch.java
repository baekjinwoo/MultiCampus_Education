package bst;

import java.util.Scanner;

public class DictionarySearch {
public static void main(String args[]){
	String word[] = 
	{"friend", "boy", "girl", "close","open",
	"school", "play", "study", "work","sleep"};	
	
	String meaning [] =
	{"친구", "소년", "소녀", "닫다", "열다",
	"학교", "놀다", "공부하다", "일하다", 
	"잠자다"	};

	//WordNode 클래스: 
	//String word , meaning , 
	//WordNode left, right 변수 4개 포함
	//setter/getter
	
	//WordBST 클래스:
	//void insert메소드("friend") : 
	//word, meaning 배열 0  word로 하는 
	//WordNode 객체 0
	//WordNode의 word 변수 사전식 나열
	
	//String find메소드("friend") : 친구
	
	//Main 클래스 :

	//10번 호출 WordBST.insert메소드("friend")
	
	//WordBST.find메소드("boy"):소년
	//WordBST.find메소드("boys"):미등록단어
	
   Scanner sc = new Scanner(System.in);
   System.out.println("찾고자 하는 단어 입력:");
   String input = sc.next();
   
   boolean flag = false;
   for(int i =0; i < word.length; i++){
	   if(input.equalsIgnoreCase(word[i])){
		   System.out.println(meaning[i]);
		   flag = true;
		   break;
	   }
	   System.out.println((i+1) +"번 반복중");
   }//for
   if(flag == false){
	   System.out.println("미등록 단어");
   }
}
}





