package bst;

public class Main {
public static void main(String[] args) {
 Node n1 = new Node(1);
 Node n2 = new Node(8);
 Node n3 = new Node(30); 
 Node n4= new Node(11);
 Node n5 = new Node(80);
 Node n6 = new Node(300); 
 Node n7 = new Node(200); 
//1 8 11 30 80 200 300 
/*               30(n3)
 *       8(n2)              200(n7)
 * 1(n1)     11(n4)    80(n5)    300(n6)
 * 
 * */
 n3.setLeft(n2);
 n3.setRight(n7);
 n2.setLeft(n1);
 n2.setRight(n4);
 n7.setLeft(n5);
 n7.setRight(n6);
 BinarySearchTree bst = new BinarySearchTree();
 bst.setRoot(n3);
 bst.display(bst.getRoot());
 
 System.out.println(bst.find(80));//t
 System.out.println(bst.find(800));//f
 //검색 데이터 존재 : x 루트.xx == id
 //검색 데이터 존재 x:  30  3
 
 BinarySearchTree bst2 = new BinarySearchTree();
//insert 노드 저장
 bst2.insert(30);//root
 //bst.display(bst2.getRoot());
 bst2.insert(1);
 //bst.display(bst2.getRoot());
 bst2.insert(100);
 bst2.insert(11);
 bst2.insert(8);
 bst2.insert(15);
 bst2.insert(90);
 bst2.insert(101);
 bst2.insert(110);
 bst2.insert(88);
 bst2.insert(150);
 bst2.insert(91);
 bst2.insert(12);
 bst2.insert(14);
 bst2.insert(80);
 bst2.insert(151);
 bst2.insert(909);//17
 

 
 System.out.println("=== 이진탐색트리 출력 ===");
 bst2.display(bst2.getRoot());
 System.out.println();
 
 //System.out.println
 //("90검색결과" + bst2.find(90));
 //System.out.println
 //("11검색결과" + bst2.find(11)); 
 System.out.println
 ("9000검색결과" + bst2.find(9000));
}
}





