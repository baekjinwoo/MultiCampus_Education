package chap8;

import java.util.Scanner;

public class Search6174 {
public static void main(String[] args) {
/* 2. 1개 4자리 숫자들(4자리 동일한 숫자 제외)
 * * 5. 뺄셈결과 == 6174  될 때까지  
   5-1. 4자리 분리 : 문자 2008 : '2' '0' '0' '8'
 * 5-2. 정렬 : 오름차순 : 가장 작은 값
 *           내림차순 : 가장 큰 값
 * 5-4. 갯수
 *            
 * */
	Scanner sc = new Scanner(System.in);
	System.out.println
	("4자리 숫자 입력(동일숫자제외)");
	String num = sc.next();
	int cnt = 0;
	if(num.equals("6174")) {
		System.out.println(cnt);
		return;
	}
	char c [] = num.toCharArray();
	int result = 0;
	Search6174 s = new Search6174();
	while(true){
		cnt++;
		int max = s.sort(c, true);//큰수(내림차순)
		int min = s.sort(c, false);//작은수(오름차순)
		System.out.println(max+":"+min);
		result = max - min;
		if(result == 6174) { break; }
	    c = s.change(result);
	}
	System.out.println(cnt);
}

public char[] change(int num){
	char[] result = new char[4];
	for(int i= result.length-1; i>=0; i-- ){
		result[i] = (char)(num % 10 + '0');
		num = num / 10;
	}
	 return result;
}

public int sort(char[] c,  boolean flag ){
	if(flag == true){
		for(int i = 0; i < c.length-1; i++){
			for(int j = 1+1; j < c.length; j++){
				if(c[i] < c[j]){
					char temp = c[j];
					c[j] = c[i];
					c[i] = temp;
				}
			}
		}
	}
	else {
		for(int i = 0; i < c.length-1; i++){
			for(int j = 1+1; j < c.length; j++){
				if(c[i] > c[j]){
					char temp = c[j];
					c[j] = c[i];
					c[i] = temp;
				}
			}
		}
	}
	//2008 {8200 0028}
	//숫자 생성
	//c[0] - '0'->8
	//c[1] - '0' -> 8*10 + 2
	//c[2] - '0' -> (8*10 + 2)*10 + 0
	//c[3] - '0' -> ((8*10 + 2)*10 + 0)*10 + 0
	int sum = 0;
	for(int i= 0; i < c.length; i++){
		sum = sum*10 + (c[i]-'0');
	}
	return sum;
}//sort end
}
