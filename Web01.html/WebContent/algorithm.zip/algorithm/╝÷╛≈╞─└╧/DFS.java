package chap9;

import java.util.ArrayList;

public class DFS {
	//Edge : adjVertex: 따라서 조회 반복
	// 이미 조회 adjVertex 리스트[1] 라면 생략
	// t/f :  
	//DFS 
	ArrayList<Edge> [] graph;
	boolean visited [];
	public DFS(ArrayList<Edge> [] graph){
		this.graph = graph;
		visited  = new boolean[graph.length];
		for(int i =0; i < visited.length; i++){
			visited[i] = false;
		}
		for(int i = 0; i < graph.length; i++){
			if(!visited[i]) dfs(i);
		}
	}
	
	public void dfs(int i){
		visited[i] = true;
		System.out.print
		("dfs(" + i + ")=" + i 
				+ " visited[" + i + "]="
				+ visited[i]
				+ " 다음 방문 정점= ");
		
		for(Edge e : graph[i]){//인접리스트
		 System.out.println(e.adjVertex);
			if(!visited[e.adjVertex]) {
			 dfs(e.adjVertex);
		 }
		}
	}
	
}	




