import java.util.Scanner;

public class ArrayTest2 {
public static void main(String[] args) {
Scanner sc = new Scanner(System.in);
System.out.println("출력 행과 열을 입력하세요");
int row = sc.nextInt();
int col = sc.nextInt();
int [][] data = new int[row][col];
int num = 0;
for(int i = 0; i < row; i++){
	if(i % 2 == 1) num = (i+1) * col + 1 ;
	else num = i * col;
	for(int j = 0; j < col ; j++){
		if(i%2 == 1){num--;}
		else{num++;}
	data[i][j] = num;
	System.out.print(data[i][j]+ "\t");
	}//inner for
	System.out.println();
}//outer for
}
}
