package primMST;

import java.util.ArrayList;
import java.util.List;

public class PrimMain {
public static void main(String args[]){
	int [][] weight = 
		{{0, 9, 10, 0, 0, 0, 0 },
		{9, 0, 0, 10, 5, 0, 3 },
		{10, 0, 0, 9, 7, 2, 0 },
		{0, 10, 9, 0, 0, 4, 8 },
		{0, 5, 7, 0, 0, 0, 1 },
		{0, 0, 2, 4, 0, 0, 6 },
		{0, 3, 0, 8, 1, 6, 0 }
		};
	
	int N = weight.length;//정점 수.7
	int M = 0;// 간선 수
	//adjList : 배열
	List<Edge> adjList [] = new List [N];
	for(int i = 0; i < N; i++ ){
		adjList[i] = new ArrayList<Edge>();
		for(int j = 0; j < N ; j++){
			if(weight[i][j] != 0){
			Edge e = new Edge(i, j,weight[i][j]);
			adjList[i].add(e);
			M++;
			}
		}
	}
	//초기 그래프 출력
	System.out.println("====초기그래프====");
	for(int i = 0; i < adjList.length; i++ ){
		for(int j = 0; j < adjList[i].size() ; j++){
			System.out.println
			("("+i+","+adjList[i].get(j).adjVertex+")="
			+adjList[i].get(j).weight);
		}
	}
	
	//프림 알고리즘 호출
	PrimMST pri = new PrimMST(adjList);
	int[] result = pri.mst(0);
	//출력
	//최단경로 (1, 2)=6 (2,3)=7 
	//오름차순 
	int sum = 0;
	System.out.println("====최단경로====");
	for(int i = 0; i < result.length; i++){
		for(Edge e:adjList[i]){
			if(e.adjVertex == result[i]){
				System.out.println
				("("+e.vertex+","
				+e.adjVertex+")="
				+e.weight);
				sum += e.weight;
			}
		}
	}
	//총합:
	System.out.println("최소신장트리경로합=" + sum);
	
}
}


/*	KruskalMST kru = new KruskalMST
			(adjList, N);
	Edge [] result = kru.mst();
	//출력
	int sum = 0;
	System.out.println("====최단경로====");
	for(int i = 0; i < result.length ; i++){
		System.out.println
		("("+result[i].vertex +","+result[i].adjVertex+")="
		+result[i].weight);
		sum += result[i].weight;
	}
	System.out.println("최단경로합"+sum);*/