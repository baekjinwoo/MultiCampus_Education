
public class ArrayTest3 {
public static void main(String ARGS[]){
	char star[][] = new char[3][3];
	
//	for(int i = 0; i < star.length; i++){
//		for(int j = 0; j <= i; j++){//별
//			star[i][j]='*';
//			System.out.print(star[i][j]);
//		}
//		System.out.println();
//	}
	
//	for(int i = 2; i >= 0; i--){//2,1,0
//		for(int j = 0 ; j <= i ; j++){//별
//			System.out.print("*");
//		}
//		System.out.println();
//	}
	
//	for(int i = 0; i < 3; i++){
//		//공백먼저
//		for(int k = 2; k >= i ; k--){
//			System.out.print(" ");
//		}
//		//*
//		for(int j = 0; j <= i; j++){
//			System.out.print("*");
//		}
//		System.out.println();
//	}

}
}
	
