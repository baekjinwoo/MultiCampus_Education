import java.util.Scanner;

public class Conversion10_2 {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("십진수 입력");
	int n = sc.nextInt();
	//10진수-진수 api
	System.out.println
	("비교중="+Integer.toBinaryString(n));
	
	int sign = 0;//양수
	if(n < 0){n = n * -1; sign = 1; }//음수
	
	char[] s = new char[32];//양수 
	char [] s2 = new char[32];//음수-이진수(2의보수)
	for(int i = 0; i < s.length; i++){
		s[i] = '0';//48
		s2[i] = '0';
	}
	int len = 0;
	while(true){
		s[len] = (char)(n % 2 + 48);  
		len++;
		n = n / 2;
		if( n == 0) break;
	}
	System.out.println(sign);
	//2-3. 1의 보수 : 0->1 변경 1 ->0 변경
	if(sign == 1){
		for(int i = 0; i < s.length; i++){
			if(s[i] == '1')  s[i] = '0';
			else s[i] = '1';
		}

	//2-4. 2의 보수 : 1의 보수 + 1
	//
	int up = 1;
	if(s[0] == '0'){
		s[0] = '1';
		for(int j= 1; j < s.length; j++){
			s2[j] = s[j];
		}
	}
	else if(s[0] =='1'){
		for(int j = 0; j < s.length; j++){
			if(up == 1){//올림수 생기는 경우
				if( (s[j]-'0' + up) == 2){
					s2[j] = '0';
					up = 1;
				}
				else if((s[j]-'0' + up) == 1){
					s2[j] = '1';
					up = 0;	
				}
			}
			else {//더이상 올림수 없는 경우
				s2[j] = s[j];
			}
		}
	}
	}
	//2의 보수 완성
	System.out.println("===결과출력===");
	if(sign == 0){
		for(int i = s.length-1; i >= 0; i--){
			System.out.print(s[i]);
		}
	}
	else if(sign == 1){
		for(int i = s.length-1; i >= 0; i--){
			System.out.print(s2[i]);
		}	
	}
	System.out.println();
}
}
