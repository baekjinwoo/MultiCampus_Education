package chap8;

public class Bubble {
public void swap(int arr[], int i, int j){
	int temp = arr[i];
	arr[i] = arr[j];
	arr[j] = temp;
}
public void bubbleSort(int [] arr){
//	for(int i = arr.length-1; i >=0; i--){
//		for(int j = 0; j < i; j++){
//	cnt++;
//			System.out.println
//			(arr[j] + ":" + arr[j+1]);
//			if(arr[j] > arr[j+1]){
//				System.out.println(1);
//				swap(arr, j, j+1);
//			}
//		}
//	}
	int cnt = 0;
	//arr 배열 데이터 갯수만큼 0,1 두개, 1,2...
/*
i=0 j=0 : [0] [1]비교	
i=0 j=1 : [1] [2]비교
...
i=0	j= [8][9]비교
===> [9] 가장 큰 값

i=1 j=0 : [0] [1]비교	
i=1 j=1 : [1] [2]비교
...
i=1	j= [7][8]비교
*/	
/*	for(int i = 0; i < arr.length; i++){
		for(int j = 0; j < arr.length-1; j++){
			cnt++;
			System.out.println
			(arr[j] + ":" + arr[j+1]);
			if(arr[j] > arr[j+1]){
				System.out.println(1);
				swap(arr, j, j+1);
			}
		}
	}*/
	
	//i=9 j=0 [0][1]
	//....
	//i=9 j=8 [8][9] 비교
	
	//i=8  j=0 
	//...
	//i = 8 j=7 [7] [8]
	for(int i = arr.length-1 ; i >= 0; i--){
		for(int j = 0; j < i; j++){
			cnt++;
			System.out.println
			(arr[j] + ":" + arr[j+1]);
			if(arr[j] > arr[j+1]){
				System.out.println(1);
				swap(arr, j, j+1);
			}
		}
	}
	System.out.println(cnt);
}
	
public void selectionSort(int arr[]){
	int cnt = 0;
	for(int i=0; i < arr.length; i++){
		int minIndex = i;//정렬되지 않은 부분의 최소값
       //정렬되지 않은 부분의 최소값 인덱스 찾기
		for(int j = i+1; j < arr.length; j++){
		 cnt++;
			if(arr[j] < arr[minIndex]){
				minIndex = j;
			}
		}
		//정렬된 부분의 값과 최소값 맞바꾸기 
		swap(arr, minIndex, i);
	}
	System.out.println(cnt);
}

public void insertionSort(int[] arr){
	//1개씩 정렬 추가 : 정렬 데이터수 증가
	//정렬되지 않은 데이터수 감소
	//현재 arr[i] 데이터 비교 대상
	for(int i = 1; i < arr.length; i++){
		int target = arr[i];
		for(int j = i; j > 0 ; j--){
			if(arr[j-1] > target){
				swap(arr, j, j-1);
			}
		}
	}
}

public void mergeSort(int [] arr){
	mergeSort(arr, 0, arr.length);
}

public void mergeSort
(int [] arr, int startIndex, int last){
	if(last - startIndex < 2){return;}
	int middleIndex = (startIndex + last) /2;
	mergeSort(arr, startIndex, middleIndex);
	mergeSort(arr, middleIndex, last);
	merge(arr, startIndex, middleIndex, last);
}

public void merge(int [] arr,int startIndex, 
		int middleIndex, int last){
	
  if(arr[middleIndex -1] <= arr[middleIndex]) return;//오름정렬되어있음
	int i = startIndex, j=middleIndex, k = 0;
	//합병임시배열. 0, 10=>(0, 5) (5, 10)
	//정렬: 양배열 첫값 비교 작은 저장, 두번째값 이동
	int[] tempArr = new int[last-startIndex];
	while(i<middleIndex && j<last)
		if(arr[i] > arr[j])
			tempArr[k++] = arr[j++]; 
		else
			tempArr[k++] = arr[i++];
		
	
	if(i < middleIndex){
		System.out.println("i=" + i + " startIndex=" + startIndex + " k="+ k
			+" middleIndex-1=" + (middleIndex-i)	);
	System.arraycopy
	(arr, i, arr, startIndex+k, middleIndex-i);
	}
	System.arraycopy
	(tempArr, 0, arr, startIndex, k);
	//테스트 확인용
	System.out.println("tempArr배열출력");
	for(int x= 0; x < tempArr.length; x++){
		System.out.print(tempArr[x]+" ");
	}
	System.out.println();
	System.out.println("arr배열출력");
	for(int x= 0; x <arr.length; x++){
		System.out.print(arr[x]+" ");
	}
	System.out.println();	
	
}
/*void merge(int[] arr, int startIndex, int middleIdex, int last) {
	  // 선조건 : arr[startIndex...middleIdex-1] 과 arr[middleIdex...last-1] 은 오름차순이다.
	  // 후조건 : arr[startIndex...last-1] 은 오름차순이다.
	  if(arr[middleIdex -1] <= arr[middleIdex]) return;//오름정렬되어있음
	  
	  int i = startIndex, j = middleIdex, k = 0; // k는 합병된 원소의 개수입니다.
	  int[] tempArr = new int[last - startIndex]; // 합병할때만 사용하는 임시 배열
	  while (i < middleIdex && j < last) // main loop
	    if(arr[i] < arr[j]) tempArr[k++] = arr[i++]; //작은값을 새 병합 배열에 넣고 작은값 가진 배열의 인덱스 증가
	    else tempArr[k++] = arr[j++]; 
	  
	  if(i < middleIdex) 
		  System.arraycopy(arr, i, arr, startIndex + k, middleIdex - i); 
	  // shift arr[i...midddleIndex - 1] 
	  System.arraycopy(tempArr, 0, arr, startIndex, k); 
}*/

public static void main(String[] args) {
	int [] arr = {4, 5, 7, 9, 8, 1, 1, 2, 3, 6}; 	
	//new Bubble().bubbleSort(arr);
	//new Bubble().selectionSort(arr);	
	//new Bubble().insertionSort(arr);
	new Bubble().mergeSort(arr);
	System.out.println("정렬결과출력");
	for(int i = 0; i < arr.length; i++){
		System.out.print(arr[i] + " ");
	}
	System.out.println();
	
}
}

