package chap9;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

public class BFS {
//특정 정점 : 큐 저장
// 반복(큐 빌 때까지) : 큐 삭제+삭제 정점 인접 점 모두 큐 저장
//1번 방문 체크 	
	ArrayList<Edge> [] graph;
	boolean visited [];
	public BFS(ArrayList<Edge> [] graph){
		this.graph = graph;
		visited  = new boolean[graph.length];
		for(int i =0; i < visited.length; i++){
			visited[i] = false;
		}
		for(int i = 0; i < graph.length; i++){
			if(!visited[i]) bfs(i);
		}
	}
	
	public void bfs(int i){
		Queue<Integer> q = 
				new LinkedList<Integer>();
		
		visited[i] = true;
		q.add(i);//현재점
		
		while(!q.isEmpty()){
			int j = q.remove();
			System.out.print(j + " ");
			//ln
//			("bfs(" + j + ")=" + j 
//					+ " visited[" + j + "]="
//					+ visited[j]
//			);
			for(Edge e : graph[j]){
				if(!visited[e.adjVertex]){
					visited[e.adjVertex] = true;
					q.add(e.adjVertex);
				}
			}
		}
	}//bfs end
}//class end	




