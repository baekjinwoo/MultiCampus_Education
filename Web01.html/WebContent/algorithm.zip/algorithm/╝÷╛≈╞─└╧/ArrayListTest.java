import java.util.ArrayList;

public class ArrayListTest {
public static void main(String[] args) {
String data = "ajsd21931u82903AKJDHAKS^&%**";
int MAX = 10; 
//문자 10개씩 잘라서 ArrayList 저장
ArrayList<String> list = 
new ArrayList<String>(1);//1+1
int length = data.length();//36개
System.out.println("문자열의 총갯수=" + length);
//10개씩 잘라서 저장
for(int i = 0; i < length; i = i + MAX){
	//i=0:(0, 10) i=10 :(10, 20) i=20 :(20, 30)
	//i=30:(30~)
	System.out.println("i+MAX = " + (i+MAX) );
	if(i+MAX < length){
	list.add(data.substring(i, i+MAX));
	}
	else{
		list.add(data.substring(i));	
	}
	System.out.println(list.size());//1 2 
}
//저장 확인
for(int i  =0; i < list.size(); i++){
	System.out.println(list.get(i));
}
//문자열 10개씩 잘라서 저장 객체 : list
//ArrayList : 배열 변환 메소드 : 배열 리턴
//{'A', 'B', 'C', 'D'}
//
}
}
