package chap9;
//인접리스트 : 
//리스트의 리스트: 
// 정점들 리스트
// 각 정점 - 인접 정점 리스트

import java.util.ArrayList;

public class Graph2 {
public static void main(String [] args) {
//	ArrayList<Integer>> [] graph = 
//	new ArrayList<Integer> [4]; 
	
	ArrayList<ArrayList<Integer>> graph = 
	new ArrayList<ArrayList<Integer>>(); 		
    //0번점
	ArrayList adjList = 
		new ArrayList<Integer>();
	adjList.add(1);
	adjList.add(2);
	graph.add(adjList);//저장순서

    //1번점
	ArrayList adjList2 = 
		new ArrayList<Integer>();
	adjList2.add(0);
	adjList2.add(3);
	graph.add(adjList2);
	
    //2번점
	ArrayList adjList3 = 
		new ArrayList<Integer>();
	adjList3.add(0);
	adjList3.add(1);
	adjList3.add(3);
	graph.add(adjList3);	

    //3번점
	ArrayList adjList4 = 
		new ArrayList<Integer>();
	adjList4.add(1);
	adjList4.add(2);
	graph.add(adjList4);

	for(int i = 0; i < graph.size(); i++){
		for(int j = 0; 
				j < graph.get(i).size();
				j++){
			System.out.println
			(i + " 정점 : " + 
			graph.get(i).get(j));
		}
	}
	
	
}//main
}//class
