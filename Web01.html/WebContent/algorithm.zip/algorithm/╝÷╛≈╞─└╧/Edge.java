package chap9;

public class Edge {
	int adjVertex;
	Edge(int adjVertex){
		this.adjVertex = adjVertex;
	}
}
