package union;

public class UnionFind {
	Node [] nodes;
	UnionFind(Node[] nodes){
		this.nodes = nodes;
		//10개(parent=0~9, rank=0)
	}
	//i가 속한 트리에서 i의 	부모를 찾아서 세팅
	//i의 부모의 부모까지 재귀 호출하여 찾는다
	int find(int i){
		if(i != nodes[i].getParent()){
			nodes[i].setParent
			(find(nodes[i].getParent()));
		}
		return nodes[i].getParent();
	}//node parent 찾아 리턴
	void union(int i, int j){
		int iroot = find(i);
		int jroot = find(j);
		if(iroot == jroot){
			return;//사이클 중지.연결불필요.방문
		}
		if(nodes[iroot].getRank()
				>
			nodes[jroot].getRank()){
			nodes[jroot].setParent(iroot);
		}
		else if(nodes[iroot].getRank()
				<
			nodes[jroot].getRank()){
			nodes[iroot].setParent(jroot);
		}
		else{//같은 경우.랜덤
			nodes[jroot].setParent(iroot);
			nodes[iroot].setRank
			(nodes[iroot].getRank()+1);//루트
		}
		
		
	}
	
}
