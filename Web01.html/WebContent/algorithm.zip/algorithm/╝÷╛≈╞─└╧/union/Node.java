package union;

public class Node {
	int parent;
	int rank;
	//두개 트리 하나로 합치면서 root 노드 : rank++ 
	public Node(int parent, int rank) {
		super();
		this.parent = parent;
		this.rank = rank;
	}
	public int getParent() {
		return parent;
	}
	public void setParent(int parent) {
		this.parent = parent;
	}
	public int getRank() {
		return rank;
	}
	public void setRank(int rank) {
		this.rank = rank;
	}
	@Override
	public String toString() {
		return 
		"parent=" + parent + ", rank=" + rank;
	}
	
	
}
