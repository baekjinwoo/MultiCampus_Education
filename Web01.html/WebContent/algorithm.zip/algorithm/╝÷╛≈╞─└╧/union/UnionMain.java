package union;

public class UnionMain {
public static void main(String[] args) {
	int N = 10;
	Node[] nodes = new Node[N];
	for(int i =0; i <= N-1; i++){
		nodes[i] = new Node(i, 0);
	}
	System.out.println("===초기 데이터===");
	for(int i = 0; i <= N-1 ; i++){
		System.out.print(nodes[i] + " ");
	}
	System.out.println("\n================");
	
//10개 (parent, rank);(0-9, 0)
	UnionFind uf = new UnionFind(nodes);
	uf.union(2, 1);
	System.out.println("===union 1번 수행===");
	for(int i = 0; i < N-1 ; i++){
		System.out.print(nodes[i] + " ");
	}
	System.out.println("\n================");
	
	uf.union(2, 6);
	uf.union(7, 3);
	uf.union(4, 5);
	uf.union(9, 5);
	uf.union(7, 2);
	uf.union(7, 8);
	uf.union(0, 4);	
	
	System.out.println("===union 8번 수행===");
	for(int i = 0; i < N-1 ; i++){
		System.out.println
		(i + ":"+nodes[i] + " ");
	}
	System.out.println("\n================");	
	
}
}
