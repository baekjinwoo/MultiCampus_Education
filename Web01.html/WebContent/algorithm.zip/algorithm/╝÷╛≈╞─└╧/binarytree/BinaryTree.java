package binarytree;

import java.util.LinkedList;
import java.util.Queue;

public class BinaryTree {
	Node root;
	public BinaryTree(Node root) {
		super();
		this.root = root;
	}
	public Node getRoot() {
		return root;
	}
	public void setRoot(Node root) {
		this.root = root;
	}
	 //1. 트리 내부 총 노드 갯수 출력
	public int size(Node n){//root
		//Node + 왼쪽 + 오른쪽 
		if(n != null){
			return 1 + 
			size(n.getLeft()) 
			+ size(n.getRight());
		}
		else{
			return 0;
		}
	}
	//2. 조회 : 부모 먼저-왼-오
	public void preOrder(Node n){
		//한줄로 출력: 각 노드 키값 출력
		if(n != null){
			System.out.print(n.getKey() + " ");
			preOrder(n.getLeft());
			preOrder(n.getRight());			
		}
	}
	 //3. 왼쪽 - 부모 중간-오
	public void inOrder(Node n){
		if(n != null){
			inOrder(n.getLeft());
			System.out.print(n.getKey() + " ");
			inOrder(n.getRight());			
		}
	}	
	 //4. 왼-오-부모 나중
	public void postOrder(Node n){
		if(n != null){
			postOrder(n.getLeft());
			postOrder(n.getRight());			
			System.out.print(n.getKey() + " ");
		}
	}
	
	 //5. 레벨 조회
	 public void levelOrder(Node n){
		 //큐
		 Queue<Node> q = new LinkedList<Node>();
		 //큐 제거-자식 큐 저장
		 q.add(n);//root
		 while(!q.isEmpty()){
			Node remove = q.poll();
			System.out.print
			(remove.getKey() + " ");
		    if(remove.getLeft() != null)
		    	q.add(remove.getLeft());
		    if(remove.getRight() != null)
		    	q.add(remove.getRight());
		 }//while end
		 
	 }
}





