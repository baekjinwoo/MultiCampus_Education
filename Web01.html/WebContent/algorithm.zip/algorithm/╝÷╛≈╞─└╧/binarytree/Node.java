package binarytree;
 
public class Node {
	int key;
	Node left;
	Node right;
	public Node(int key, Node left, Node right) {
		super();
		this.key = key;
		this.left = left;
		this.right = right;
	}
	public int getKey() {
		return key;
	}
	public void setKey(int key) {
		this.key = key;
	}
	public Node getLeft() {
		return left;
	}
	public void setLeft(Node left) {
		this.left = left;
	}
	public Node getRight() {
		return right;
	}
	public void setRight(Node right) {
		this.right = right;
	}
}

	
//public static void main(String args[]){
//Node<String> c=new Node<String>("c", null, null);
//Node<String> b=new Node<String>("b", null, null);
//Node<String> a=new Node<String>("a", b, c);
//System.out.println(c.getKey());
//System.out.println(b.getKey());
//System.out.println(a.getKey());
//}

//Node n1 = new Node(11, b, c);


