import java.util.Stack;

public class StackTest {
public static void main(String args[]){
	Stack st = new Stack();
	System.out.println(st.isEmpty());//true
	st.push(100);
	st.push("stack");
	st.push(new StackTest());
	System.out.println(st.peek());
	int cnt = 0;
	while(!st.isEmpty()){
		System.out.println(st.pop()); 
		System.out.println(++cnt);
	}
}
}
