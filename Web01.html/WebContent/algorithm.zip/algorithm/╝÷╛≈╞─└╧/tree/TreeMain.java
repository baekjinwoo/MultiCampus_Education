package tree;

import java.util.ArrayList;

/*      A
 * B    C  D
 * E F     G
 * 
 * */
public class TreeMain {
public static void main(String[] args) {
	Node a = new Node("A", null);
	Node b = new Node("B", a);
	Node c = new Node("C", a, null);
	Node d = new Node("D", a);

	Node e = new Node("E", b, null);
	Node f = new Node("F", b, null);
	Node g = new Node("G", d, null);
//b자식설정
	ArrayList<Node> b_list = 
			new ArrayList<Node>();
	b_list.add(e);
	b_list.add(f);	
	b.setChildren(b_list);
//d자식설정	
	ArrayList<Node> d_list = 
			new ArrayList<Node>();
	d_list.add(g);
	d.setChildren(d_list);
//b, d 자식설정 이전
//a자식설정	
	ArrayList<Node> a_list = 
			new ArrayList<Node>();
	a_list.add(b);
	a_list.add(c);
	a_list.add(d);
	a.setChildren(a_list);
	
	//a를 루트로 설정 트리 객체 생성
	MultiChildrenTree tree =
		new MultiChildrenTree(a);
	//a.printAllNode();//자식부터
	tree.printQueue();//형제부터
	
	//===================================
	//tree 루트 노드 이름 출력
//	System.out.println
//	("루트=" + tree.root.getName());
//	//b 노드 부모 노드 이름 출력
//	System.out.println
//	("b의 부모=" +b.getParent().getName());
//	//b 노드 자식 객체들 갯수와 이름들 출력
//	ArrayList<Node> list = 
//			b.getChildren();
//	for(Node n : list){
//		System.out.println(n.getName());
//	}
//	System.out.println
//	("총 자식노드수=" + list.size());
}
}




