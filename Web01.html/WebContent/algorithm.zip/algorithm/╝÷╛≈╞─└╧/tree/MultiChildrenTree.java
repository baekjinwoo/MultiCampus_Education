package tree;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

class Node{//노드정보출력기능
	String name;
	Node parent;
	ArrayList<Node> children;
	public Node(){}
	public Node(String name, Node parent){
		this.name = name ;
		this.parent = parent;
	}
	public Node(String name, Node parent,
			ArrayList<Node> children){
		this.name = name ;
		this.parent = parent;
		this.children = children;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Node getParent() {
		return parent;
	}
	public void setParent(Node parent) {
		this.parent = parent;
	}
	public ArrayList<Node> getChildren() {
		return children;
	}
	public void setChildren(ArrayList<Node> children) {
		this.children = children;
	}
	
	public void printAllNode(){
		printNode();
		if(children != null){
		 for(int i = 0; i < children.size(); i++){
			children.get(i).printAllNode();
		 }			
		}
	}
	
	public void printNode(){
System.out.println("--------노드 정보 확인-------");
if(parent != null){
	System.out.println("부모 노드 : " + parent.getName() );
}
else{
	System.out.println("부모 노드 : 없음");
}
System.out.println("현재 노드 : " + name);
if(children != null){
	System.out.println
	("자식 노드 갯수 :" + children.size());
	System.out.println
	("자식 노드 명단 : ");	
	for(int i = 0; i < children.size(); i++){
	System.out.println(i+":"+children.get(i).getName());
	}
}else{
	System.out.println("자식 노드 갯수 : 0");
	System.out.println("자식 노드 명단 : 없음");	
}
System.out.println
("------------------------------");
	}

}//Node class
public class MultiChildrenTree {
	Node root;
	public MultiChildrenTree() {}
	public MultiChildrenTree(Node root) {
		this.root = root;
	}

	public void printQueue(){
		Queue<Node> q = new LinkedList<Node>();
		q.add(root);
		Node n = q.poll();
		n.printNode();
		if(n.getChildren() != null){
			for(int i = 0; 
			i < n.getChildren().size(); i++){	
				q.add(n.getChildren().get(i));
			}
		}
		while(!q.isEmpty()){
			n = q.poll();
			n.printNode();
			if(n.getChildren() != null){
				for(int i = 0; 
				i < n.getChildren().size(); i++){	
					q.add(n.getChildren().get(i));
				}
			}	
		}
		//큐 저장 제거/출력 + 자식노드 add
		
	}
}


