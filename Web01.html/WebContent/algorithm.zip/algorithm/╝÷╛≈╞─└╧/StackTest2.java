import java.util.Stack;

public class StackTest2 {
public static boolean match(char[] cs) { 
	boolean result = false;
	Stack<Character> stack = 
			new Stack<Character>();
	char [] open= {'{' , '<', '[', '('};
	char[] close = {'}', '>', ']', ')'};
	outer:for(int i = 0; i < cs.length; i++){
		for(int j = 0; j < open.length; j++){
			if(cs[i] == close[j]){//닫힘괄호
				if(!stack.isEmpty()){
					char pop = stack.pop();
					if(pop == open[j]){
						result = true;
					}
					else {
						result = false;
						break outer;
					}
				}
				else{ 
					result = false;
					break outer;
				}
			}
			else if(cs[i] == open[j]){//열림괄호
				stack.push(cs[i]);
				System.out.println
				("cs[" + i + "]=" + cs[i] + " 푸쉬");
			}
		}
	}
	// cs[0]:open 데이터중 1개 일치:push
	// cs[0]:close 데이터중 1개 일치: 
	// 예) cs[0] 데이터와 close[2] 동일하다면
	// pop한 데이터와 open[2] 동일 :result=>true
	//                             false
	// 스택 empty : 
	return result;
}
public static void main(String[] args) {
    char[] first = { '(','[', '<', '{', '}', '>', ']', ')' };
	char[] second = {'(','[', '<', '{', '>', '}', ']', ')' };
	char[] third = { '(', 'a', 'c', ')', '[', '{', '}', ']' };
	//System.out.println(match(first)); // t
	//System.out.println(match(second)); // f
	System.out.println(match(third)); // t
}
}





//public class StackTest2 {
//public static boolean match(char[] cs) { 
//	boolean result = false;
//	Stack<Character> stack = 
//			new Stack<Character>();
//	char [] open= {'{' , '<', '[', '('};
//	char[] close = {'}', '>', ']', ')'};
//	outer:for(int i = 0; i < cs.length; i++){
//		System.out.println("====>확인중 ==cs[" + i + "]=" + cs[i]);
//		for(int j = 0; j < open.length; j++){
//			if(cs[i] == close[j]){//닫힘괄호이면
//				if(!stack.isEmpty()){//스택에 데이터 존재시
//					char pop = stack.pop();//스택 팝하여
//					if(pop == open[j]){//열림괄호쌍이랑 일치?
//						result = true;
//						System.out.println("i= " + i + ", j= " + j + ":" +  pop + cs[i] +":" +":" + result);
//					}
//					else{//열림괄호쌍이랑 불일치
//						result = false;
//						System.out.println("불일치");
//						break outer;//더이상 반복 수행 의미없음. 바깥 반복문 수행 종료
//					}
//				}
//				else{//스택 비었음
//					System.out.println("비었음");
//					result = false;
//					break outer;
//				}
//			}
//			else if(cs[i] == open[j]){//열림괄호이면
//				stack.push(cs[i]);//스택 푸쉬
//				System.out.println("cs[" + i + "]=" + cs[i] + " 저장");
//			}
//		}
//	}
//	
//	// cs[0]:open 데이터중 1개 일치:push
//	// cs[0]:close 데이터중 1개 일치: 
//	// 예) cs[0] 데이터와 close[2] 동일하다면
//	// pop한 데이터와 open[2] 동일 :result=>true
//	//                             false
//	// 스택 empty : 
//	return result;
//}
//public static void main(String[] args) {
// // char[] first = { '(','[', '<', '{', '}', '>', ']', ')' };
////	char[] second = {'(','[', '<', '{', '>', '}', ']', ')' };
////	char[] third = { '(', 'a', 'c', ')', '[', '{', '}', ']' };
//    char[] first = { '(','[', '<', '{', '}', '}', '>', ']', ')' };
//	char[] second = {'(','[', '<', '{', '}', '>', '}', ']', ')' };
//	char[] third = { '(', 'a', 'c', ')', ')', '[', '{', '}', ']' };
//	System.out.println(match(first)); // t
//	System.out.println(match(second)); // f
//	System.out.println(match(third)); // t
//}
//}