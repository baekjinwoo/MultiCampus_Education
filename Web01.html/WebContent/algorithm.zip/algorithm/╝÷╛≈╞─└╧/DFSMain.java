package chap9;

import java.util.ArrayList;

//인접리스트
public class DFSMain {
public static void main(String[] args) {
	ArrayList<Edge> [] graph = 
			new ArrayList [10];
	graph[0] = new ArrayList<Edge>();
	Edge e1 = new Edge(1);
	Edge e2 = new Edge(2);
	graph[0].add(e1);
	graph[0].add(e2);
	
	graph[1] = new ArrayList<Edge>();
	Edge e3 = new Edge(0);
	Edge e4 = new Edge(3);
	graph[1].add(e3);
	graph[1].add(e4);
	
	graph[2] = new ArrayList<Edge>();
	Edge e5 = new Edge(0);
	Edge e6 = new Edge(3);
	graph[2].add(e5);
	graph[2].add(e6);
	
	graph[3] = new ArrayList<Edge>();
	Edge e7 = new Edge(1);
	Edge e8 = new Edge(2);
	Edge e9 = new Edge(8);
	Edge e10 = new Edge(9);	
	graph[3].add(e7);
	graph[3].add(e8);
	graph[3].add(e9);
	graph[3].add(e10);
	
	graph[4] = new ArrayList<Edge>();
	Edge e11 = new Edge(5);
	graph[4].add(e11);

	graph[5] = new ArrayList<Edge>();
	Edge e12 = new Edge(4);
	Edge e13 = new Edge(6);
	Edge e14 = new Edge(7);
	graph[5].add(e12);
	graph[5].add(e13);
	graph[5].add(e14);

	graph[6] = new ArrayList<Edge>();
	Edge e15 = new Edge(5);
	Edge e16 = new Edge(7);
	graph[6].add(e15);
	graph[6].add(e16);
	
	graph[7] = new ArrayList<Edge>();
	Edge e17 = new Edge(5);
	Edge e18 = new Edge(6);
	graph[7].add(e17);
	graph[7].add(e18);
	
	graph[8] = new ArrayList<Edge>();
	Edge e19 = new Edge(3);
	graph[8].add(e19);
	
	graph[9] = new ArrayList<Edge>();
	Edge e20 = new Edge(3);
	graph[9].add(e20);
	
	for(int i = 0; i < graph.length;i++){
		for(Edge e: graph[i]){
			System.out.println
			(i+ " 정점 연결 - "+ e.adjVertex);
		}
	}
}
}
