import java.util.Scanner;

public class ArrayTest1 {
public static void main(String[] args) {
Scanner sc = new Scanner(System.in);
System.out.println("출력 행과 열을 입력하세요");
int row = sc.nextInt();
int col = sc.nextInt();
int [][] data = new int[row][col];
// int : (char)100--> 컴퓨터 십진수->이진수
//문자-->십진수(ASCII)-->이진수 저장
// 'A'-->65 'B' 'a'-->97  '0'--> 48~57
//int max = row * col;//20
/*홀수행(1,3)=(짝수인덱스:0,2) : 행인덱스 * 5 부터 시작 1씩 증가
짝수행(2,4)=(홀수인덱스:1,3) : (행인덱스 + 1)*5 부터 시작 1씩 감소
*/
int num = 0;
for(int i = 0; i < row; i++){//4행
	if(i % 2 == 1){//홀수인덱스=짝수번째행
		num = (i + 1) * col + 1;//2*5=10
	}
	else{
		num = i * col; //i=2, num = 10
	}
	for(int j = 0; j < col ; j++){//5열
		if(i % 2 == 1){num --;}
		else{ num++; }
	data[i][j] = num;
	System.out.print(data[i][j]+ "\t");//5개
	}//inner for
	System.out.println();//4번 줄바꿈
}//outer for
}
}
